import React, { useEffect } from 'react';
import { List, ListItemButton, ListItemText, Paper, Typography } from '@mui/material';

const StockList = ({ stocks, setSelectedStock }) => {
    console.log(stocks);
    return (
        <Paper elevation={3} style={{ padding: '10px'}}>
            <Typography variant="h6" gutterBottom>
                Most Active Stocks
            </Typography>
            <List style={{ height: '76vh' ,overflowX:'hidden', overflowY: 'auto'}}>
                {stocks.map((stock) => (
                    <ListItemButton key={stock.symbol} onClick={() => setSelectedStock(stock)}>
                        <ListItemText primary={stock?.description} secondary={stock.symbol} />
                    </ListItemButton>
                ))}
            </List>
        </Paper>
    );
};

export default StockList;
